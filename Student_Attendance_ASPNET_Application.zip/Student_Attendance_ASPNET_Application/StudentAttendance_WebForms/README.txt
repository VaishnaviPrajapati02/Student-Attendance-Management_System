STUDENT ATTENDANCE MANAGEMENT SYSTEM - ASP.NET WEB FORMS
Semester 5 Tiny Project

Technology: ASP.NET Web Forms, C#, ADO.NET, SQL Server, Visual Studio 2022, .NET Framework 4.8.

SETUP:
1. Open SQL Server Management Studio.
2. Run the StudentAttendanceDB.sql file from the parent folder.
3. Open StudentAttendance.csproj in Visual Studio 2022.
4. Check Web.config. Default connection uses SQL Server instance '.'.
5. If needed, change Data Source in Web.config.
6. Build and run using IIS Express.

PAGES:
Default.aspx - Home page
Students.aspx - Add and display students
Attendance.aspx - Mark Present/Absent attendance

Demo database records are included in StudentAttendanceDB.sql.
