using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace StudentAttendance.Web {
    public partial class Attendance : System.Web.UI.Page {
        string cs = ConfigurationManager.ConnectionStrings["StudentAttendanceDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e) {
            if (!IsPostBack) {
                txtDate.Text = DateTime.Today.ToString("yyyy-MM-dd");
                LoadSubjects();
            }
        }

        private void LoadSubjects() {
            using (SqlConnection con = new SqlConnection(cs))
            using (SqlDataAdapter da = new SqlDataAdapter("SELECT SubjectId, SubjectName FROM Subjects ORDER BY SubjectName", con)) {
                DataTable dt = new DataTable(); da.Fill(dt);
                ddlSubject.DataSource = dt; ddlSubject.DataTextField = "SubjectName"; ddlSubject.DataValueField = "SubjectId";
                ddlSubject.DataBind();
            }
        }

        protected void btnLoad_Click(object sender, EventArgs e) {
            using (SqlConnection con = new SqlConnection(cs))
            using (SqlDataAdapter da = new SqlDataAdapter(
                "SELECT StudentId, EnrollmentNo, StudentName FROM Students ORDER BY EnrollmentNo", con)) {
                DataTable dt = new DataTable(); da.Fill(dt);
                gvAttendance.DataSource = dt; gvAttendance.DataBind();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e) {
            DateTime date = DateTime.Parse(txtDate.Text);
            int subjectId = int.Parse(ddlSubject.SelectedValue);
            using (SqlConnection con = new SqlConnection(cs)) {
                con.Open();
                foreach (GridViewRow row in gvAttendance.Rows) {
                    int studentId = int.Parse(row.Cells[0].Text);
                    DropDownList status = (DropDownList)row.FindControl("ddlStatus");
                    using (SqlCommand cmd = new SqlCommand(
                        "INSERT INTO Attendance(StudentId,SubjectId,AttendanceDate,Status) VALUES(@s,@sub,@d,@st)", con)) {
                        cmd.Parameters.AddWithValue("@s", studentId);
                        cmd.Parameters.AddWithValue("@sub", subjectId);
                        cmd.Parameters.AddWithValue("@d", date.Date);
                        cmd.Parameters.AddWithValue("@st", status.SelectedValue);
                        try { cmd.ExecuteNonQuery(); } catch (SqlException) { /* duplicate record */ }
                    }
                }
            }
            lblMessage.Text = "Attendance saved.";
        }
    }
}