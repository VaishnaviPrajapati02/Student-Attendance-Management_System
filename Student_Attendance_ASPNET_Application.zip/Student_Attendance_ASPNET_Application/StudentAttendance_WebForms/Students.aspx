<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Students.aspx.cs" Inherits="StudentAttendance.Web.Students" %>
<!DOCTYPE html>
<html>
<head runat="server"><title>Students</title></head>
<body>
<form id="form1" runat="server">
<div style="margin:40px;font-family:Arial">
<h2>Student Management</h2>
<asp:Label ID="lblMessage" runat="server" />
<br/><br/>
Enrollment No:
<asp:TextBox ID="txtEnrollment" runat="server" />
Student Name:
<asp:TextBox ID="txtName" runat="server" />
Semester:
<asp:TextBox ID="txtSemester" runat="server" Width="50" />
Division:
<asp:TextBox ID="txtDivision" runat="server" Width="50" />
<asp:Button ID="btnAdd" runat="server" Text="Add Student" OnClick="btnAdd_Click" />
<hr/>
<asp:GridView ID="gvStudents" runat="server" AutoGenerateColumns="true" />
</div>
</form>
</body>
</html>