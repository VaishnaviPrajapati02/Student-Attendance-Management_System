using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentAttendance.Web {
    public partial class Students : System.Web.UI.Page {
        string cs = ConfigurationManager.ConnectionStrings["StudentAttendanceDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e) {
            if (!IsPostBack) LoadStudents();
        }

        protected void btnAdd_Click(object sender, EventArgs e) {
            using (SqlConnection con = new SqlConnection(cs))
            using (SqlCommand cmd = new SqlCommand(
                "INSERT INTO Students(EnrollmentNo,StudentName,Semester,Division) VALUES(@e,@n,@s,@d)", con)) {
                cmd.Parameters.AddWithValue("@e", txtEnrollment.Text.Trim());
                cmd.Parameters.AddWithValue("@n", txtName.Text.Trim());
                cmd.Parameters.AddWithValue("@s", int.Parse(txtSemester.Text));
                cmd.Parameters.AddWithValue("@d", txtDivision.Text.Trim());
                con.Open();
                cmd.ExecuteNonQuery();
            }
            lblMessage.Text = "Student added successfully.";
            LoadStudents();
        }

        private void LoadStudents() {
            using (SqlConnection con = new SqlConnection(cs))
            using (SqlDataAdapter da = new SqlDataAdapter(
                "SELECT StudentId, EnrollmentNo, StudentName, Semester, Division FROM Students ORDER BY StudentId DESC", con)) {
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvStudents.DataSource = dt;
                gvStudents.DataBind();
            }
        }
    }
}