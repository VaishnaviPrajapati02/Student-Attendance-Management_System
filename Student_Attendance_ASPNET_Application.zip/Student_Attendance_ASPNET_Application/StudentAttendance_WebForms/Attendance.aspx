<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Attendance.aspx.cs" Inherits="StudentAttendance.Web.Attendance" %>
<!DOCTYPE html>
<html>
<head runat="server"><title>Attendance</title></head>
<body>
<form id="form1" runat="server">
<div style="margin:40px;font-family:Arial">
<h2>Attendance</h2>
Date:
<asp:TextBox ID="txtDate" runat="server" TextMode="Date" />
Subject:
<asp:DropDownList ID="ddlSubject" runat="server" />
<asp:Button ID="btnLoad" runat="server" Text="Load Students" OnClick="btnLoad_Click" />
<br/><br/>
<asp:GridView ID="gvAttendance" runat="server" AutoGenerateColumns="false">
<Columns>
<asp:BoundField DataField="StudentId" HeaderText="ID" />
<asp:BoundField DataField="EnrollmentNo" HeaderText="Enrollment No" />
<asp:BoundField DataField="StudentName" HeaderText="Student Name" />
<asp:TemplateField HeaderText="Status">
<ItemTemplate>
<asp:DropDownList ID="ddlStatus" runat="server">
<asp:ListItem>Present</asp:ListItem>
<asp:ListItem>Absent</asp:ListItem>
</asp:DropDownList>
</ItemTemplate>
</asp:TemplateField>
</Columns>
</asp:GridView>
<br/>
<asp:Button ID="btnSave" runat="server" Text="Save Attendance" OnClick="btnSave_Click" />
<asp:Label ID="lblMessage" runat="server" />
</div>
</form>
</body>
</html>