<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="StudentAttendance.Web.Default" %>
<!DOCTYPE html>
<html>
<head runat="server">
    <title>Student Attendance Management System</title>
    <style>
        body{font-family:Arial;background:#f3f6fa;margin:0}
        .box{width:700px;margin:80px auto;background:white;padding:35px;border-radius:12px;text-align:center}
        h1{margin-bottom:10px}.btn{display:inline-block;padding:12px 22px;margin:8px;background:#1f5f8b;color:white;text-decoration:none;border-radius:6px}
    </style>
</head>
<body>
<form id="form1" runat="server">
<div class="box">
    <h1>Student Attendance Management System</h1>
    <p>Semester 5 .NET Tiny Project</p>
    <asp:HyperLink ID="lnkStudents" runat="server" NavigateUrl="Students.aspx" CssClass="btn">Students</asp:HyperLink>
    <asp:HyperLink ID="lnkAttendance" runat="server" NavigateUrl="Attendance.aspx" CssClass="btn">Attendance</asp:HyperLink>
</div>
</form>
</body>
</html>