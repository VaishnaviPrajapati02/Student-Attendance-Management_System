CREATE DATABASE StudentAttendanceDB;
GO

USE StudentAttendanceDB;
GO

CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role NVARCHAR(20) NOT NULL DEFAULT 'Teacher'
);
GO

CREATE TABLE Students (
    StudentId INT IDENTITY(1,1) PRIMARY KEY,
    EnrollmentNo NVARCHAR(30) NOT NULL UNIQUE,
    StudentName NVARCHAR(100) NOT NULL,
    Semester INT NOT NULL,
    Division NVARCHAR(10) NULL
);
GO

CREATE TABLE Subjects (
    SubjectId INT IDENTITY(1,1) PRIMARY KEY,
    SubjectCode NVARCHAR(20) NOT NULL UNIQUE,
    SubjectName NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE Attendance (
    AttendanceId INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL,
    SubjectId INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    Status NVARCHAR(10) NOT NULL CHECK (Status IN ('Present','Absent')),
    CONSTRAINT FK_Attendance_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_Attendance_Subjects FOREIGN KEY (SubjectId) REFERENCES Subjects(SubjectId),
    CONSTRAINT UQ_Attendance UNIQUE (StudentId, SubjectId, AttendanceDate)
);
GO

INSERT INTO Users (Username, PasswordHash, Role)
VALUES ('admin', 'admin123', 'Admin');
GO

INSERT INTO Students (EnrollmentNo, StudentName, Semester, Division)
VALUES
('BCA001', 'Student One', 5, 'A'),
('BCA002', 'Student Two', 5, 'A'),
('BCA003', 'Student Three', 5, 'A');
GO

INSERT INTO Subjects (SubjectCode, SubjectName)
VALUES
('DOTNET', '.NET Programming'),
('DBMS', 'Database Management System');
GO

-- Example attendance
INSERT INTO Attendance (StudentId, SubjectId, AttendanceDate, Status)
VALUES
(1, 1, CAST(GETDATE() AS DATE), 'Present'),
(2, 1, CAST(GETDATE() AS DATE), 'Present'),
(3, 1, CAST(GETDATE() AS DATE), 'Absent');
GO

-- Attendance report example
SELECT
    s.EnrollmentNo,
    s.StudentName,
    sub.SubjectName,
    COUNT(a.AttendanceId) AS TotalClasses,
    SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) AS PresentClasses,
    SUM(CASE WHEN a.Status = 'Absent' THEN 1 ELSE 0 END) AS AbsentClasses,
    CAST(
        100.0 * SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END)
        / NULLIF(COUNT(a.AttendanceId), 0)
        AS DECIMAL(5,2)
    ) AS AttendancePercentage
FROM Students s
JOIN Attendance a ON s.StudentId = a.StudentId
JOIN Subjects sub ON a.SubjectId = sub.SubjectId
GROUP BY s.EnrollmentNo, s.StudentName, sub.SubjectName;
GO
