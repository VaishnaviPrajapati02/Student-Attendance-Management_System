STUDENT ATTENDANCE MANAGEMENT SYSTEM
ASP.NET Web Forms - Semester 5 Tiny Project

Open Student_Attendance_ASPNET.sln in Visual Studio 2022.
Run StudentAttendanceDB.sql in SQL Server first.
Then build and run with IIS Express.

Main files are inside StudentAttendance_WebForms.
